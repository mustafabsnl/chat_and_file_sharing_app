<?php
session_start();

// Oturumu sonlandır
session_destroy();

// Kullanıcıyı index.php sayfasına yönlendir
header("Location: giris.php");
exit();

