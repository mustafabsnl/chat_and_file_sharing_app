<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klasör İçeriği</title>
    <style>
        body {
            background-image: url('anayurtGiris2.png');
            font-family: 'Poppins', sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            margin: 20px auto;
        }
        h2 {
            color: #007bff;
            text-align: center;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin-bottom: 10px;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .back-button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
        .back-button:focus {
            outline: none;
        }
        .back-button:active {
            transform: translateY(1px);
        }
        .back-button-icon {
            vertical-align: middle;
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Klasör İçeriği</h2>
        <ul>
            <?php
            $dosya_dizini = 'C:\\xampp\\htdocs\\mesajlasma\\uploads\\'; 
            $dosyalar = glob($dosya_dizini . '*');
            foreach ($dosyalar as $dosya) {
                $dosya_adi = basename($dosya);
                echo '<li><a href="download.php?dosya=' . urlencode($dosya_adi) . '">' . $dosya_adi . '</a></li>';
            }
            ?>
        </ul>
        <a class="back-button" href="index.php">
            <span class="back-button-icon">↩️</span> Geri Dön
        </a>
    </div>
</body>
</html>
