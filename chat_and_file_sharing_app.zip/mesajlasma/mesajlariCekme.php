<?php
session_start();

if (!isset($_SESSION['UserName'])) {
    header("Location: giris.php");
    exit();
}

$UserName = $_SESSION['UserName'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mesajlasma";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$selectedUser = isset($_GET['user']) ? $_GET['user'] : null;

if (!$selectedUser) {
    echo json_encode([]);
    exit();
}

$sql_messages = "SELECT * FROM sohbet WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) ORDER BY timestamp ASC";
$stmt = $conn->prepare($sql_messages);
$stmt->bind_param("ssss", $UserName, $selectedUser, $selectedUser, $UserName);
$stmt->execute();
$result_messages = $stmt->get_result();

$messages = [];
while ($row = $result_messages->fetch_assoc()) {
    $messages[] = $row;
}

echo json_encode($messages);

$conn->close();

