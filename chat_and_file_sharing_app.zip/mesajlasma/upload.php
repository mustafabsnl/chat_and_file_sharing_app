<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["dosya"])) {
    $dosya = $_FILES["dosya"];
    $hedef_dizin = 'uploads/';
    $hedef_dosya = $hedef_dizin . basename($dosya["name"]);
    if (move_uploaded_file($dosya["tmp_name"], $hedef_dosya)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Dosya yükleme sırasında bir hata oluştu.";
    }
} else {
    header("Location: index.php");
    exit;
}

