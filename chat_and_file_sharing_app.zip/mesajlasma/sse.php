// sse.php
<?php
header("Content-Type: text/event-stream");
header("Cache-Control: no-cache");

// Veritabanı bağlantısı
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mesajlasma";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Gelen kullanıcıyı al
$selectedUser = isset($_GET['user']) ? $_GET['user'] : null;

// Mesajları al
$sql_messages = "SELECT * FROM sohbet WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) ORDER BY timestamp ASC";
$stmt = $conn->prepare($sql_messages);
$stmt->bind_param("ssss", $UserName, $selectedUser, $selectedUser, $UserName);
$stmt->execute();
$result_messages = $stmt->get_result();

$messages = [];
while ($row = $result_messages->fetch_assoc()) {
    $messages[] = $row;
}

echo "data: " . json_encode($messages) . "\n\n";

$conn->close();
?>
