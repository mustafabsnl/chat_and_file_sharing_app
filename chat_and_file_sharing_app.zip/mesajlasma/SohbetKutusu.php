<?php
session_start();

// Oturum kontrolü yap
if (!isset($_SESSION['UserName'])) {
    header("Location: giris.php");
    exit();
}

$UserName = $_SESSION['UserName'];

// Veritabanı bağlantısını yap
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mesajlasma";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Mesaj gönderildiğinde veritabanına kaydet
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && isset($_POST['receiver'])) {
    $message = $_POST['message'];
    $receiver = $_POST['receiver'];
    $stmt = $conn->prepare("INSERT INTO sohbet (sender, receiver, message, timestamp) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("sss", $UserName, $receiver, $message);
    $stmt->execute();
    $stmt->close();
    exit();
}

// Kullanıcıları çek
$sql_users = "SELECT UserName FROM giris WHERE UserName != ?";
$stmt = $conn->prepare($sql_users);
$stmt->bind_param("s", $UserName);
$stmt->execute();
$result_users = $stmt->get_result();

// Mesajları çek
$selectedUser = isset($_GET['user']) ? $_GET['user'] : null;
$sql_messages = "SELECT * FROM sohbet WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) ORDER BY timestamp ASC";
$stmt = $conn->prepare($sql_messages);
$stmt->bind_param("ssss", $UserName, $selectedUser, $selectedUser, $UserName);
$stmt->execute();
$result_messages = $stmt->get_result();

// Hata kontrolü ekleyin
if ($result_messages === false) {
    echo "SQL hatası: " . $conn->error;
    exit();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoş Geldiniz</title>
    <style>
        body {
            background-image: url('anayurtGiris2.png');
            display: flex;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
        }
        .selected-user {
            color: white;
            text-align: center; 
        }
        .sidebar {
            background-color: #fff; 
            border-right: 2px solid #ccc;
            width: 25%;
            background-image: url('anayurtGiris2.png');
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            overflow-y: auto;
            height: 100vh;
        }
        .sidebar h2 {
            text-align: center;
            color: white;
        }
        .user-list {
            list-style-type: none;
            padding: 0;
        }
        .user-list li {
            padding: 10px;
            background-color: #ffffff;
            margin-bottom: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            cursor: pointer;
            text-align: center;
        }
        .user-list li:hover {
            background-color: #e0e0e0;        
        }
        .chat-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 75%;
            padding: 20px;
        }
        .chat-box {
            border: 1px solid #ccc;
            padding: 10px;
            width: 100%;
            background-color: white;
            overflow-y: auto;
            max-height: 300px;
            margin-bottom: 20px;
        }
        .chat-box div {
            padding: 5px;
            margin-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        .chat-box .username {
            font-weight: bold;
        }
        .chat-box .timestamp {
            font-size: 0.8em;
            color: #999;
        }
        .message-form {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }
        .message-form input[type="text"] {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 10px;
        }
        .message-form input[type="submit"] {
            width: 18%;
            padding: 10px;
            border: none;
            background-color: white;
            color: black;
            border-radius: 5px;
            cursor: pointer;
        }
        .message-form input[type="submit"]:hover {
            background-color: white;
        }
        a {
            text-decoration: none; /* Link altını kaldırır */
        }
        a.button {
            color: white;
            margin-top: 20px;
        }
        .message-form .file-upload-button {
        width: 18%;
        padding: 10px;
        border: none;
        background-color: white;
        color: black;
        border-radius: 5px;
        cursor: pointer;
        text-align: center;
        font-size: 14px;
        box-shadow: 0 0 5px rgba(0,0,0,0.1);
        margin-left: 10px; 
        }
        .message-form .file-upload-button:hover {
        background-color: #f0f0f0; 
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var messageInput = document.querySelector('.message-form input[name="message"]');
            var messageForm = document.querySelector('.message-form');
            var chatBox = document.querySelector('.chat-box');
            var userListItems = document.querySelectorAll('.user-list li');
            var selectedUser = "<?php echo htmlspecialchars($selectedUser); ?>";

            function loadMessages(user) {
                fetch("getMessages.php?user=" + user)
                    .then(response => response.json())
                    .then(data => {
                        chatBox.innerHTML = '';
                        data.forEach(function(message) {
                            var messageDiv = document.createElement('div');
                            var usernameSpan = document.createElement('span');
                            var messageSpan = document.createElement('span');
                            var timestampDiv = document.createElement('div');

                            usernameSpan.className = 'username';
                            usernameSpan.textContent = message.sender + ": ";
                            messageSpan.className = 'message';
                            messageSpan.textContent = message.message;
                            timestampDiv.className = 'timestamp';
                            timestampDiv.textContent = message.timestamp;

                            messageDiv.appendChild(usernameSpan);
                            messageDiv.appendChild(messageSpan);
                            messageDiv.appendChild(timestampDiv);

                            chatBox.appendChild(messageDiv);
                        });
                        // Mesaj kutusunun en altına kaydır
                        chatBox.scrollTop = chatBox.scrollHeight;
                    })
                    .catch(function(error) {
                        console.error("Mesajları alırken bir hata oluştu:", error);
                    });
            }
            function checkNewMessages() {
                fetch("bildirim.php")
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(function(message) {
                            showNotification(message.sender, message.message);
                        });
                    })
                    .catch(function(error) {
                        console.error("Yeni mesajları kontrol ederken bir hata oluştu:", error);
                    });
            }

            function showNotification(title, message) {
                if (Notification.permission === 'granted') {
                    new Notification(title, {
                        body: message,
                        icon: 'C:/xampp/htdocs/mesajlasma/bildirim.png'
                    });
                }
            }
            if (Notification.permission !== 'granted') {
                Notification.requestPermission();
            }

    userListItems.forEach(function(item) {
        item.addEventListener('click', function() {
            selectedUser = item.textContent;
            document.querySelector('.selected-user').textContent = selectedUser;
            document.querySelector('.message-form input[name="receiver"]').value = selectedUser;
            window.history.pushState({}, "", "?user=" + encodeURIComponent(selectedUser));
            loadMessages(selectedUser);
        });
    });

    messageForm.addEventListener("submit", function(e) {
        e.preventDefault();
        sendMessage();
    });

    messageInput.addEventListener("keypress", function(e) {
        if (e.key === "Enter") {
            e.preventDefault();
            sendMessage();
        }
    });

    function sendMessage() {
        var message = messageInput.value.trim();
        if (!selectedUser || message === "") return;
        var formData = new FormData(messageForm);
        formData.append('receiver', selectedUser);
        fetch("", {
            method: "POST",
            body: formData      
        }).then(function(response) {
            return response.text();
        }).then(function() {
            messageInput.value = "";
            loadMessages(selectedUser);
        }).catch(function(error) {
            console.error("Mesaj gönderimi sırasında bir hata oluştu:", error);
        });
    }

    // Seçili kullanıcıyı güncelle
    if (selectedUser) {
        document.querySelector('.selected-user').textContent = selectedUser;
        loadMessages(selectedUser);
        setInterval(function() {
            loadMessages(selectedUser);
        }, 500); // Her yarım saniyede bir mesajları yeniler
    }
});
    </script>
</head>
<body>
    <div class="sidebar">
        <h2>Kayıtlı Kullanıcılar</h2>
        <ul class="user-list">
            <?php
            if ($result_users->num_rows > 0) {
                while ($row = $result_users->fetch_assoc()) {
                    echo "<li>" . htmlspecialchars($row["UserName"]) . "</li>";
                }
            } else {
                echo "<li>Hiç kullanıcı bulunamadı</li>";
            }
            ?>  
        </ul>   
    </div>  
    <div class="chat-container">    
        <h2 class="selected-user">Kullanıcı seçiniz</h2>
        <div class="chat-box">
            <?php if ($result_messages->num_rows > 0): ?>
                <?php while ($row = $result_messages->fetch_assoc()): ?>
                    <div>
                        <span class="username"><?php echo htmlspecialchars($row['sender']); ?>:</span>
                        <span class="message"><?php echo htmlspecialchars($row['message']); ?></span>
                        <div class="timestamp"><?php echo $row['timestamp']; ?></div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>Mesaj bulunamadı.</p>
            <?php endif; ?>
        </div>

        <form class="message-form" action="" method="post">
            <input type="hidden" name="receiver" value="<?php echo htmlspecialchars($selectedUser); ?>">
            <input type="text" name="message" placeholder="Mesajınızı yazın" required>
            <input type="submit" value="Gönder">
            <button type="button" class="file-upload-button" onclick="window.location.href='index.php'">Dosya Yükleme</button>
        </form>
        <br>
        <a href="cikis.php" class="button">Çıkış Yap</a>
    </div>  
</body>
</html>

<?php $conn->close(); ?>
