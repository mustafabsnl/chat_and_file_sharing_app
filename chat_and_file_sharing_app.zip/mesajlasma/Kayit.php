<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Hesap Oluştur</title>
    <style>
        body {
          background-image: url('');
          background-repeat: no-repeat;
          background-attachment: fixed;
          background-size: 100% 100%;
        }
        </style>
    <style>
        body {
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: "Roboto", sans-serif;
            font-size:20px;
        }
        .register-container {
            background-color: white;
            padding: 55px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        .register-container h2 {
            color: darkblue;
            margin-bottom: 20px;
        }
        .register-container form {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }
        .register-container input[type="text"],
        .register-container input[type="email"],
        .register-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .register-container input[type="submit"] {
            background-color: darkblue;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;

        }
        .register-container input[type="submit"]:hover {
            background-color: #293180;
        }
        .login-link {
            margin-top: 20px;
            display: block;
            color: darkblue;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Yeni Hesap Oluştur</h2>
        <form action="Kayit.php" method="POST">
            <input type="email" name="email" placeholder="E-posta" required>
            <input type="text" name="username" placeholder="Kullanıcı Adı" required>
            <input type="password" name="password" placeholder="Şifre" required>
            <input type="submit" value="Kayıt Ol">
        </form>
        <a class="login-link" href="giris.php">Zaten bir hesabınız var mı? Giriş Yapın  </a>
    </div>
</body>
</html>

<?php 
include("veriTabaniBaglanti.php");

if(isset($_POST["email"],$_POST["username"],$_POST["password"]))
{
    $UserMail=$_POST["email"];
    $UserName=$_POST["username"];
    $UserPassword=$_POST["password"];

    $stmt = $conn->prepare("INSERT INTO giris (UserMail, UserName, UserPassword) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $UserMail, $UserName, $UserPassword);

        if ($stmt->execute()) {
            echo "<script>
                alert('Kaydınız başarıyla oluşturulmuştur.');
                window.location.href = 'giris.php';
            </script>";
        } else {
            echo "Hata: " . $stmt->error;
        }
        
        $stmt->close();
        
    }   



$conn->close();
?>