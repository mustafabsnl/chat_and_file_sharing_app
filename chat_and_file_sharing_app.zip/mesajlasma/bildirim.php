<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Bildirimi</title>
</head>
<body>
    <h1>Kullanıcı Bildirimi Örneği</h1>
    <button id="notifyButton">Bildirim Gönder</button>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            // Bildirim iznini kontrol et
            if (Notification.permission !== 'granted') {
                // Kullanıcıdan izin iste
                Notification.requestPermission();
            }

            // Bildirim gönderme butonuna tıklama olayını dinle
            document.getElementById('notifyButton').addEventListener('click', () => {
                // Örnek kullanıcı adı ve mesaj
                let userName = '$userName'; 
                let message = 'Yeni mesajınız var!';
                sendNotification(userName, message);
            });

            function sendNotification(userName, message) {
                // Bildirim izni kontrolü
                if (Notification.permission === 'granted') {
                    new Notification(`Yeni mesajdan ${userName}`, {
                        body: message,
                        icon: 'pngwing.com.png' 
                    });
                } else {
                    alert('Bildirim izni verilmedi.');
                }
            }
        });
    </script>
</body>
</html>
<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

// Her 10 saniyede bir yeni mesaj olup olmadığını kontrol et
while (true) {
    // Örnek veri: kullanıcı adı ve mesaj
    $userName = '$userName'; 
    $message = 'Yeni mesajınız var!';
    
    echo "data: {\"userName\": \"$userName\", \"message\": \"$message\"}\n\n";
    ob_flush();
    flush();
    sleep(1); // 1 saniye bekle
}


