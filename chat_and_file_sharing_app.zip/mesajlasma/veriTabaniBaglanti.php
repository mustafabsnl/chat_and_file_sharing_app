<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<?php
$servername = "localhost";
$username = "root";  
$password = "";      
$dbname = "mesajlasma";


$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) 
{
    die("Bağlantı hatası: " . mysqli_connect_error());
}
?>
