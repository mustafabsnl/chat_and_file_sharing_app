<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";      
$password = "";          
$dbname = "mesajlasma"; 


$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Bağlantı hatası: " . mysqli_connect_error());
}

session_start();


$UserName = $_POST['username'];
$UserPassword = $_POST['password'];


$sql = "SELECT * FROM giris WHERE UserName = '$UserName' AND UserPassword = '$UserPassword'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    
    $_SESSION['UserName'] = $UserName;
    header("Location: SohbetKutusu.php"); 
    exit();
} else {
    header("Location: giris.php?error=1"); 
    exit();
}

$conn->close();

