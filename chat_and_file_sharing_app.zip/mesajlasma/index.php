<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dosya Yükleme ve İndirme</title>
    <style>
        body {
            background-image: url('anayurtGiris2.png');
            font-family: 'Poppins', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
            color:#007bff;
            display: block;
            margin-bottom: 5px;
        }
        .form-group input[type=file] {
            border: 1px solid #ddd;
            padding: 8px;
            border-radius: 4px;
            width: 100%;
        }
        .form-group input[type=submit] {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group input[type=submit]:hover {
            background-color: #0056b3;
        }
        .download-button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
            cursor: pointer;
        }
        .download-button:hover {
            background-color: #0056b3;
        }
        .back-button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="text-align: center; color: #007bff;">Dosya Yükleme ve İndirme </h2>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="dosya">Dosya Seçin:</label>
                <input type="file" name="dosya" id="dosya" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Dosyayı Yükle">
            </div>
        </form>
        <hr>
        <h3 style="color: #007bff;">İndirilebilir Dosyalar</h3>
        <a class="download-button" href="index2.php" >
        <span class="download-button-icon">📁</span> Klasöre Git
        </a>
        <a class="back-button" href="SohbetKutusu.php">
            <span class="back-button-icon">↩️</span> Geri Dön
        </a>
    </div>
</body>
</html>

     <!-- <ul>
            <?php
            $dosya_dizini = 'htdocs\mesajlasma\uploads\\'; 
            $dosyalar = glob($dosya_dizini . '*');
            foreach ($dosyalar as $dosya) {
                $dosya_adi = basename($dosya);
                echo '<li><a href="download.php?dosya=' . urlencode($dosya_adi) . '">' . $dosya_adi . '</a></li>';
            }
            ?>
     </ul>  -->

     