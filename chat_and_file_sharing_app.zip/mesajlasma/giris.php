<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>  
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Girişi</title>
    <style>
        body {
            background-image: url('');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        </style>
    <style>
        body {
            background-size: cover; 
            background-color: darkblue;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: "Roboto", sans-serif;
            font-size: 23px;
        }
        .login-container {
            background-color: white;
            padding: 55px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;           
        }
        .login-container h2 {
            color: darkblue;
            margin-bottom: 10px;
            margin-top: 0px;
        }
        .login-container form {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }
        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-container input[type="submit"] {
            background-color: darkblue;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .login-container input[type="submit"]:hover {
            background-color: #293180;
        }
        .register-link {
            margin-top: 20px;
            display: block;
            color: darkblue;
            text-decoration: none;
            font-size: 14px;
        }
        .error-message {
            color: red;
            font-size: 12px;
            margin-top: 10px;
        }
    </style>    
</head>
<body>
    <div class="login-container">
    
        <h2>Kullanıcı Girişi</h2>

        <?php if (isset($_GET['error']) && $_GET['error'] == 1): ?>
            <p class="error-message">Kullanıcı adı veya şifre hatalı.</p>
        <?php endif; ?>
        
        <form action="VeriTabaniKontrol.php" method="POST">
            <input type="text" name="username" placeholder="Kullanıcı Adı" required>
            <input type="password" name="password" placeholder="Şifre" required>
            <input type="submit" value="Giriş Yap">
        </form>
        
        <a class="register-link" href="Kayit.php"> Üye Değil Misin? Yeni Hesap Oluştur</a>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$('.mesaj a').click(function(){
    $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
 });
 
</script>
</html>

<?php 
include("veriTabaniBaglanti.php");
?>
