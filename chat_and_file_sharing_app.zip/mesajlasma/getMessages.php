<?php
session_start();

// Oturum kontrolü yap
if (!isset($_SESSION['UserName'])) {
    header("Location: giris.php");
    exit();
}

$UserName = $_SESSION['UserName'];

// GET parametresinden kullanıcı adını al
if (!isset($_GET['user'])) {
    echo json_encode([]);
    exit();
}

$selectedUser = $_GET['user'];

// Veritabanı bağlantısını yap
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mesajlasma";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Mesajları çek
$sql = "SELECT * FROM sohbet WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) ORDER BY timestamp ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $UserName, $selectedUser, $selectedUser, $UserName);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = [
        'sender' => $row['sender'],
        'message' => $row['message'],
        'timestamp' => $row['timestamp']
    ];
}

$stmt->close();
$conn->close();

// JSON formatında döndür
header('Content-Type: application/json');
echo json_encode($messages);

