<?php
// Dosya yolu kontrolü ve geçerliliği için
if (isset($_GET['dosya']) && !empty($_GET['dosya'])) {
    $dosya_adi = basename($_GET['dosya']);
    $dosya_yolu = 'C:\\xampp\\htdocs\\mesajlasma\\uploads\\' . $dosya_adi;

    // Dosyanın var olup olmadığını kontrol et
    if (file_exists($dosya_yolu)) {
        // HTTP başlıklarını ayarla
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $dosya_adi . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($dosya_yolu));
        flush(); // Çıktıyı temizle
        readfile($dosya_yolu);
        exit;
    } else {
        echo "Dosya bulunamadı.";
    }
} else {
    echo "Geçersiz dosya isteği.";
}
